from django.apps import AppConfig


class DashboardConfig(AppConfig):
    name = 'dashboard'
